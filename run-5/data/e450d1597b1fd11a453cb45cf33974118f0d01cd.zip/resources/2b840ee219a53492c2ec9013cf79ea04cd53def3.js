import{r as t}from"./vendor-state-pbn9p2ew.js";function n(e){const r=t.useRef(e);r.current=e,t.useEffect(()=>()=>{r.current()},[])}export{n as u};
