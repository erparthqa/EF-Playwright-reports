import"./react-tooltip.min-CvjGVaJo.js";import{$ as o,a0 as t,a1 as a}from"./react-tooltip.min-cuXZg3Qs.js";const i=`
:root {
  --rt-color-white: #fff;
  --rt-color-dark: var(--color-gray-800) !important;
  --rt-color-success: var(--color-success-darker) !important;
  --rt-color-error: var(--color-error-darker) !important;
  --rt-color-warning: var(--color-warning-darker) !important;
  --rt-color-info: var(--color-info-darker) !important;
  --rt-opacity: 1;
  --rt-transition-show-delay: 0.15s;
  --rt-transition-closing-delay: 0.15s;
}

:root.dark {
  --rt-color-white: var(--color-dark-50) !important;
  --rt-color-dark: var(--color-dark-500) !important;
}

.tooltip-multiline {
  max-width: 360px !important;
  white-space: normal !important;
  word-break: break-word !important;
  line-height: 1.5 !important;
}`,r=o();t(r,i);a(r);
