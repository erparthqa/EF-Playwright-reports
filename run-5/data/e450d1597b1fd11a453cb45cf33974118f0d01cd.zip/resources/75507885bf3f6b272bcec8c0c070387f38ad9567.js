const a=e=>{var t;if(!e)return"";const r=e.replace(/[^a-fA-F0-9]/g,"").toUpperCase();return r.length!==12?e:((t=r.match(/.{1,2}/g))==null?void 0:t.join(":"))||e};export{a as M};
