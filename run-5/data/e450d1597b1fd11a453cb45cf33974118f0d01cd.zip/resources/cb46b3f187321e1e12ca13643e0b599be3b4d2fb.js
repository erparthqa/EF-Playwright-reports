function a(t,o){return o?`${t} OBD PLUG-IN`:`${t} Battery Powered`}function r(t){return t?`${t} Bluetooth Tag`:"Bluetooth Tag"}export{r as a,a as f};
