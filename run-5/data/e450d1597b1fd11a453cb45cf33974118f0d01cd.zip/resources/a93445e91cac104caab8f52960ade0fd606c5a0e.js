(function() {
  window._POSTHOG_REMOTE_CONFIG = window._POSTHOG_REMOTE_CONFIG || {};
  window._POSTHOG_REMOTE_CONFIG['phc_RCxGgXK6BzLejwxk6ig9bqh584rHJrV6sAnXt4HteSi'] = {
    config: {"token": "phc_RCxGgXK6BzLejwxk6ig9bqh584rHJrV6sAnXt4HteSi", "supportedCompression": ["gzip", "gzip-js"], "hasFeatureFlags": false, "captureDeadClicks": false, "capturePerformance": {"network_timing": true, "web_vitals": true, "web_vitals_allowed_metrics": null}, "autocapture_opt_out": false, "autocaptureExceptions": true, "analytics": {"endpoint": "/i/v0/e/"}, "elementsChainAsString": true, "errorTracking": {"autocaptureExceptions": true, "suppressionRules": []}, "sessionRecording": false, "heatmaps": true, "surveys": false, "defaultIdentifiedOnly": true},
    siteApps: []
  }
})();